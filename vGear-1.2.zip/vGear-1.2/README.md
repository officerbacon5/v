# vGear
Gear up whenever you (re)spawn or press a button (configurable).
